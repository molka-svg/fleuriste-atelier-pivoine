<?php
/**
 * Commande — étapes ① Vos coordonnées et ② Livraison ou retrait
 *
 * Remplace le bloc « Détails de facturation » de WooCommerce. Les champs sont
 * les mêmes, simplement répartis en deux étapes. Les cartes « Livraison » /
 * « Retrait » sont déplacées dans #ap-shipping-choice par main.js.
 *
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined('ABSPATH') || exit;

$fields      = $checkout->get_checkout_fields('billing');
$contact_ids = ['billing_first_name', 'billing_last_name', 'billing_phone', 'billing_email'];
?>
<div class="woocommerce-billing-fields">
    <?php do_action('woocommerce_before_checkout_billing_form', $checkout); ?>

    <section class="ap-step">
        <h3 class="ap-step-title"><span class="ap-step-num">1</span> Vos coordonnées</h3>
        <div class="woocommerce-billing-fields__field-wrapper">
            <?php
            foreach ($contact_ids as $key) {
                if (isset($fields[$key])) {
                    woocommerce_form_field($key, $fields[$key], $checkout->get_value($key));
                }
            }
            ?>
        </div>
    </section>

    <section class="ap-step">
        <h3 class="ap-step-title"><span class="ap-step-num">2</span> Livraison ou retrait</h3>
        <div class="ap-shipping-choice" id="ap-shipping-choice" aria-live="polite"></div>
        <div class="ap-address">
            <p class="ap-address-title">Votre adresse</p>
            <div class="woocommerce-billing-fields__field-wrapper">
                <?php
                foreach ($fields as $key => $field) {
                    if (!in_array($key, $contact_ids, true)) {
                        woocommerce_form_field($key, $field, $checkout->get_value($key));
                    }
                }
                ?>
            </div>
        </div>
        <p class="ap-pickup-note">Votre bouquet vous attend à l'atelier, 27 rue Imaginaire, Paris 11e.</p>
    </section>

    <?php do_action('woocommerce_after_checkout_billing_form', $checkout); ?>
</div>

<?php if (!is_user_logged_in() && $checkout->is_registration_enabled()) : ?>
    <div class="woocommerce-account-fields">
        <?php if (!$checkout->is_registration_required()) : ?>
            <p class="form-row form-row-wide create-account">
                <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
                    <input class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" id="createaccount" <?php checked((true === $checkout->get_value('createaccount') || (true === apply_filters('woocommerce_create_account_default_checked', false))), true); ?> type="checkbox" name="createaccount" value="1" /> <span><?php esc_html_e('Create an account?', 'woocommerce'); ?></span>
                </label>
            </p>
        <?php endif; ?>

        <?php do_action('woocommerce_before_checkout_registration_form', $checkout); ?>

        <?php if ($checkout->get_checkout_fields('account')) : ?>
            <div class="create-account">
                <?php foreach ($checkout->get_checkout_fields('account') as $key => $field) : ?>
                    <?php woocommerce_form_field($key, $field, $checkout->get_value($key)); ?>
                <?php endforeach; ?>
                <div class="clear"></div>
            </div>
        <?php endif; ?>

        <?php do_action('woocommerce_after_checkout_registration_form', $checkout); ?>
    </div>
<?php endif; ?>
